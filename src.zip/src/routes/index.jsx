import App from 'containers/App/App.jsx';

var indexRoutes = [
    { path: "/", name: "Home", component: App }
];

export default indexRoutes;
