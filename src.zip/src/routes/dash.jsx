import Dashboard from 'views/Dashboard/Dashboard.jsx';

import ReadAllUser from 'views/User/ReadAllUser.jsx';
import CreateUser from 'views/User/CreateUser.jsx';
import ReadOneUser from 'views/User/ReadOneUser.jsx';

import ReadAllOrder from 'views/Order/ReadAllOrder.jsx';
import CreateOneOrder from 'views/Order/CreateOneOrder.jsx';
import BaristaReadAll from 'views/Order/BaristaReadAll.jsx';
import CashierReadAll from 'views/Order/CashierReadAll.jsx';

import Buttons from 'views/Components/Buttons.jsx';
import GridSystem from 'views/Components/GridSystem.jsx';
import Panels from 'views/Components/Panels.jsx';
import SweetAlert from 'views/Components/SweetAlertPage.jsx';
import Notifications from 'views/Components/Notifications.jsx';
import Icons from 'views/Components/Icons.jsx';
import Typography from 'views/Components/Typography.jsx';
import RegularForms from 'views/Forms/RegularForms.jsx';
import ExtendedForms from 'views/Forms/ExtendedForms.jsx';
import ValidationForms from 'views/Forms/ValidationForms.jsx';
import Wizard from 'views/Forms/Wizard/Wizard.jsx';
import RegularTables from 'views/Tables/RegularTables.jsx';
import ExtendedTables from 'views/Tables/ExtendedTables.jsx';
import DataTables from 'views/Tables/DataTables.jsx';
import GoogleMaps from 'views/Maps/GoogleMaps.jsx';
import FullScreenMap from 'views/Maps/FullScreenMap.jsx';
import VectorMap from 'views/Maps/VectorMap.jsx';
import Charts from 'views/Charts/Charts.jsx';
import Calendar from 'views/Calendar/Calendar.jsx';
import UserPage from 'views/Pages/UserPage.jsx';

import pagesRoutes from './pages.jsx';

import CreateCustomer from 'views/Customer/CreateCustomer.jsx';
import ReadAllCustomer from 'views/Customer/ReadAllCustomer.jsx';
import ReadOneCustomer from 'views/Customer/ReadOneCustomer.jsx';
import CreateEmployee from 'views/Employee/CreateEmployee.jsx';
import ReadAllEmployee from 'views/Employee/ReadAllEmployee.jsx';
import ReadOneEmployee from 'views/Employee/ReadOneEmployee.jsx';

import CreateCategory from'views/Category/CreateCategory.jsx';
import ReadAllCategory from'views/Category/ReadAllCategory.jsx';
import ReadOneCategory from'views/Category/ReadOneCategory.jsx';

import CreateFood from'views/Food/CreateFood.jsx';
import ReadAllFood from'views/Food/ReadAllFood.jsx';
import ReadOneFood from'views/Food/ReadOneFood.jsx';

import CreateMenu from'views/Menu/CreateMenu.jsx';
import ReadAllMenu from'views/Menu/ReadAllMenu.jsx';
import ReadOneMenu from'views/Menu/ReadOneMenu.jsx';

var pages = [{ path: "/pages/user-page", name: "User Page", mini: "UP", component: UserPage }].concat(pagesRoutes);

var dashRoutes = [
    { path: "/dashboard", name: "Dashboard", icon: "pe-7s-graph", component: Dashboard },
    { collapse: true, path: "/Order", name: "Order", state: "openOrder", icon: "pe-7s-plugin", views:[
        { path: "/Order/ReadAll", name: "ReadAll", mini: "B", component: ReadAllOrder },
        { path: "/Order/CreateOneOrder", name: "Create", mini: "B", component: CreateOneOrder },
        { path: "/Order/BaristaReadAll", name: "BaristaReadAll", mini: "B", component: BaristaReadAll },
        { path: "/Order/CashierReadAll", name: "CashierReadAll", mini: "B", component: CashierReadAll }]
        
    },
    { collapse: true, path: "/User", name: "User", state: "openUser", icon: "pe-7s-plugin", views:[
        { path: "/User/ReadAll", name: "ReadAll", mini: "B", component: ReadAllUser },
        { path: "/User/Create", name: "Create", mini: "B", component: CreateUser },
        { path: "/User/ReadOneUser", name: "Read", mini: "B", component: ReadOneUser }]
        
    },
    { collapse: true, path: "/customer", name: "Customer", state: "openCustomer", icon: "pe-7s-star", views:
    [
        { path: "/customer/ReadAllCustomer", name: "Read All Customer", mini: "RAC", component: ReadAllCustomer },
        { path: "/customer/ReadOneCustomer", name: "Read One Customer", mini: "ROC", component: ReadOneCustomer },
        { path: "/customer/CreateCustomer", name: "Create Customer", mini: "CC", component: CreateCustomer }
    ]
    },
    { collapse: true, path: "/employee", name: "Employee", state: "openEmployee", icon: "pe-7s-id", views:
    [
        { path: "/employee/ReadAllEmployee", name: "ReadAllEmployee", mini: "RAE", component: ReadAllEmployee },
        { path: "/employee/ReadOneEmployee", name: "Read One Employee", mini: "ROE", component: ReadOneEmployee },
        { path: "/employee/CreateEmployee", name: "CreateEmployee", mini: "CE", component: CreateEmployee }
    ]
    },

    { collapse: true, path: "/Category", name: "Category", state: "openCategory", icon: "pe-7s-note2", views:
    [
        { path: "/Category/ReadAllCategory", name: "ReadAllCategory", mini: "RA", component: ReadAllCategory },
        { path: "/Category/ReadOneCategory", name: "ReadOneCategory", mini: "RO", component: ReadOneCategory },
        { path: "/Category/CreateCategory", name: "CreateCategory", mini: "C", component: CreateCategory }
    ]
    },
    { collapse: true, path: "/Food", name: "Food", state: "openFood", icon: "pe-7s-note2", views:
    [
        { path: "/Food/ReadAllFood", name: "ReadAllFood", mini: "RA", component: ReadAllFood },
        { path: "/Food/ReadOneFood", name: "ReadOneFood", mini: "RO", component: ReadOneFood },
        { path: "/Food/CreateFood", name: "CreateFood", mini: "C", component: CreateFood }
    ]
    },
    { collapse: true, path: "/Menu", name: "Menu", state: "openMenu", icon: "pe-7s-note2", views:
    [
        { path: "/Menu/ReadAllMenu", name: "ReadAllMenu", mini: "RA", component: ReadAllMenu },
        { path: "/Menu/ReadOneMenu", name: "ReadOneMenu", mini: "RO", component: ReadOneMenu },
        { path: "/Menu/CreateMenu", name: "CreateMenu", mini: "C", component: CreateMenu }
    ]
    },




    { collapse: true, path: "/components", name: "Components", state: "openComponents", icon: "pe-7s-plugin", views:[
        { path: "/components/button", name: "Buttons", mini: "B", component: Buttons },
        { path: "/components/grid-system", name: "Grid System", mini: "GS", component: GridSystem },
        { path: "/components/panels", name: "Panels", mini: "P", component: Panels },
        { path: "/components/sweet-alert", name: "Sweet Alert", mini: "SA", component: SweetAlert },
        { path: "/components/notifications", name: "Notifications", mini: "N", component: Notifications },
        { path: "/components/icons", name: "Icons", mini: "I", component: Icons },
        { path: "/components/typography", name: "Typography", mini: "T", component: Typography }]
    },
    { collapse: true, path: "/forms", name: "Forms", state: "openForms", icon: "pe-7s-note2", views:
        [{ path: "/forms/regular-forms", name: "Regular Forms", mini: "RF", component: RegularForms },
        { path: "/forms/extended-forms", name: "Extended Forms", mini: "EF", component: ExtendedForms },
        { path: "/forms/validation-forms", name: "Validation Forms", mini: "VF", component: ValidationForms },
        { path: "/forms/wizard", name: "Wizard", mini: "W", component: Wizard }]
    },
    { collapse: true, path: "/tables", name: "Tables", state: "openTables", icon: "pe-7s-news-paper", views:
        [{ path: "/tables/regular-tables", name: "Regular Tables", mini: "RT", component: RegularTables },
        { path: "/tables/extended-tables", name: "Extended Tables", mini: "ET", component: ExtendedTables },
        { path: "/tables/data-tables", name: "Data Tables", mini: "DT", component: DataTables }]
    },
    { collapse: true, path: "/maps", name: "Maps", state: "openMaps", icon: "pe-7s-map-marker", views:
        [{ path: "/maps/google-maps", name: "Google Maps", mini: "GM", component: GoogleMaps },
        { path: "/maps/full-screen-maps", name: "Full Screen Map", mini: "FSM", component: FullScreenMap },
        { path: "/maps/vector-maps", name: "Vector Map", mini: "VM", component: VectorMap }]
    },
    { path: "/charts", name: "Charts", icon: "pe-7s-graph1", component: Charts },
    { path: "/calendar", name: "Calendar", icon: "pe-7s-date", component: Calendar },
    { collapse: true, path: "/pages", name: "Pages", state: "openPages", icon:"pe-7s-gift", views:
        pages
    },
    { redirect: true, path: "/", pathTo: "/pages/login-page", name: "Login" }
];
export default dashRoutes;
