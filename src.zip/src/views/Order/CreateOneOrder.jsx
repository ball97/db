import React, { Component } from 'react';
import {
    Grid, Row, Col,
    Nav, NavItem,
    Tab
} from 'react-bootstrap';

import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';

var Categoryrow = ""

var list = [];

var listcategoryid = []

var listloc = []



const columnchonloai = [{
    dataField: 'Name',
    text: 'Name',
    sort: true
},
{
    dataField: 'Image',
    text: 'Image',
    formatter: ImageFormatter
}

];

function ImageFormatter(cell, row) {
    return (
        <img src={cell} height="100px" />
    );
}

const options = {
    sizePerPageList: [5, 10, 20, 50]
}

class CreateOneOrder extends Component {

    constructor(props) {
        super(props)
        this.state = {
            menudetailitems: [],
            listcategory:[],
            rowEvents: {
                // onClick: (e, row, rowIndex) => {
                //     //console.log(`clicked on row with index: `, OrderIDrow);
                //     //this.xulytrong(listOrder,OrderIDrow)
                // },
                // onMouseEnter: (e, row, rowIndex) => {
                //     Categoryrow = row.OrderID;
                // }
            }
        }
        this.xulylaylistcategoryid = this.xulylaylistcategoryid.bind(this)
        this.xulylocdistinctcategoryid = this.xulylocdistinctcategoryid.bind(this)
        this.GetFullInfoCategoryFromCategoryID = this.GetFullInfoCategoryFromCategoryID.bind(this)
    }


    xulylaylistcategoryid(list) {
        var newlist=[]
        for (var i = 0; i < list.length; i++) {
            newlist.push(list[i].CategoryID)
        }
        this.xulylocdistinctcategoryid(newlist)
    }

    xulylocdistinctcategoryid(list) {
        var newlistloc = [...new Set(list)];
        this.GetFullInfoCategoryFromCategoryID(newlistloc)

    }

    GetFullInfoCategoryFromCategoryID(listloc) {
        var listcategoryfull=[]
        for (var i = 0; i < listloc.length; i++) {
            fetch('http://localhost:3002/categories/' + listloc[i])
                .then(res => res.json())
                .then(json => {
                    //let data = xulu(json.data)
                    //console.log(json.data);
                    listcategoryfull.push(json)
                    this.setState({listcategory:listcategoryfull})
                });
        }

    }

    componentDidMount() {
        console.log('didmount')
        fetch('http://localhost:3003/menu/details/Menu001')
            .then(res => res.json())
            .then(json => {
                //let data = xulu(json.data)
                //console.log(json.data);
                this.xulylaylistcategoryid(json.data);
                this.setState({
                    menudetailitems: json.data
                })
            });
    }

    render() {
        console.log(this.state.listcategory)
        return (
            <div className="main-content">
                <Grid fluid>
                    <Row>
                        <Col md={6}>
                        
                        <BootstrapTable keyField='ID' data={this.state.listcategory} columns={columnchonloai} pagination={paginationFactory(options)} filter={filterFactory()}  />
                        </Col>
                    </Row>

                </Grid>
            </div>
        );
    }
}

export default CreateOneOrder;
