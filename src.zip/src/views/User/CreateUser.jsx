import React, { Component } from 'react';
import {
    Grid, Row, Col,
    FormGroup, ControlLabel, FormControl, Form
} from 'react-bootstrap';

import Card from 'components/Card/Card.jsx';
import Button from 'elements/CustomButton/CustomButton.jsx';
import Select from 'react-select';

const formData = { "data": {} };

const listemployeeID = [

];

const listroleID = [];

var emID="";
var roleid="";

function xulu(list) {

    for (var i = 0; i < list.length; i++) {

        listemployeeID.push({ value: list[i].EmployeeID, label: list[i].EmployeeID + ' - ' + list[i].Name })
    };
    return listemployeeID;
}

function xulu1(list) {

    for (var i = 0; i < list.length; i++) {

        listroleID.push({ value: list[i].RoleID, label: list[i].RoleID + ' - ' + list[i].Name })
    };
    return listroleID;
}

class Create extends Component {
    constructor(props) {
        super(props);
        // this.state = {
        //     radio: "1",
        //     radioVariant: "1"
        // };
        this.state = {
            listemployee: null,
            listrole: null,
            EmployeeIDSelect: null,
            RoleIDSelect: null,
            usernameError:null,
            passwordError:null
        };
        this.handleUsername = this.handleUsername.bind(this);
        this.handlePassword = this.handlePassword.bind(this);
        this.handleEmployeeID = this.handleEmployeeID.bind(this);
    }

    componentDidMount() {
        console.log('didmount')
        fetch('http://localhost:3002/employees')
            .then(res => res.json())
            .then(json => {
                let data = xulu(json.data)

                this.setState({
                    listemployee: data
                })
            });

        fetch('http://localhost:3003/roles')
            .then(res => res.json())
            .then(json => {
                let data = xulu1(json.data)

                this.setState({
                    listrole: data
                })
            });
    }

    handleSubmit(event) {
        event.preventDefault();
        //console.log('handleSubmit', 'bam')
        console.log('handleSubmit', formData)

        //const data = new FormData(event.target);

        // console.log('body', data)
        // fetch('http://localhost:3001/Categorys', {
        //     method: 'POST',
        //     body: data,
        // });


        //}
        // console.log('-->', formData);
        fetch('http://localhost:3001/register', {
            method: 'POST',
            body: JSON.stringify(formData),
        });
    }

    handleUsername(Event) {
        formData.data[Event.target.id] = Event.target.value;
        //console.log(Event.target.value)
        Event.target.value.length < 1 ? this.setState({ usernameError: (<small className="text-danger">You must enter a username of at least 1 characters.</small>) }):this.setState({ usernameError: null });
    }

    handlePassword(event) {
        formData.data[event.target.id] = event.target.value;
        //console.log(event.target.value)   
        event.target.value.length < 6 ? this.setState({ passwordError: (<small className="text-danger">You must enter a password of at least 6 characters.</small>) }):this.setState({ passwordError: null });
    }

    handleEmployeeID() {
        console.log(this.state.EmployeeIDSelect)
        formData.data['EmployeeID'] = emID;
    }

    handleRoleID() {
        console.log(this.state.EmployeeIDSelect)
        formData.data['RoleID'] = roleid;
    }

    render() {
        
        return (
            <div className="main-content">
                <Grid fluid>
                    <Row>
                        <Col md={12}>
                            <Card
                                title={<legend>Create User</legend>}
                                content={
                                    <Form horizontal onSubmit={(event) => this.handleSubmit(event)} >
                                        <fieldset>
                                            <FormGroup>
                                                <ControlLabel className="col-sm-2">
                                                    Username <span className="star">*</span>
                                                </ControlLabel>
                                                <Col sm={6}>
                                                    <FormControl
                                                        id="Username"
                                                        type="text"
                                                        onChange={(event) => this.handleUsername(event)}
                                                    />
                                                    {this.state.usernameError}
                                                </Col>
                                            </FormGroup>
                                        </fieldset>
                                        <fieldset>
                                            <FormGroup>
                                                <ControlLabel className="col-sm-2">
                                                    Password <span className="star">*</span>
                                                </ControlLabel>
                                                <Col sm={6}>
                                                    <FormControl
                                                        id="HashPassword"
                                                        type="password"
                                                        onChange={(event) => this.handlePassword(event)}
                                                    />
                                                    {this.state.passwordError}
                                                </Col>
                                            </FormGroup>
                                        </fieldset>
                                        <fieldset>
                                            <FormGroup>
                                                <ControlLabel className="col-sm-2">
                                                    Employee ID <span className="star">*</span>
                                                </ControlLabel>
                                                <Col md={6}>
                                                    <Select
                                                        id="EmployeeID"
                                                        placeholder="Single Select"
                                                        name="EmployeeIDSelect"
                                                        value={this.state.EmployeeIDSelect}
                                                        options={this.state.listemployee}
                                                        onChange={(value) => {
                                                            emID=value.value
                                                            this.setState({ EmployeeIDSelect: value.value })
                                                            this.handleEmployeeID()
                                                                            }
                                                        }
                                                    />
                                                </Col>
                                            </FormGroup>
                                        </fieldset>
                                        <fieldset>
                                            <FormGroup>
                                                <ControlLabel className="col-sm-2">
                                                    Role ID <span className="star">*</span>
                                                </ControlLabel>
                                                <Col md={6}>
                                                    <Select
                                                        id="roleid"
                                                        placeholder="Single Select"
                                                        name="RoleIDSelect"
                                                        value={this.state.RoleIDSelect}
                                                        options={this.state.listrole}
                                                        onChange={(value) => {
                                                            roleid=value.value
                                                            this.setState({ RoleIDSelect: value.value })
                                                            this.handleRoleID()
                                                        }
                                                        }
                                                    />
                                                </Col>
                                            </FormGroup>
                                        </fieldset>

                                        <Button bsStyle="info" fill type='submit'>
                                            Submit
                                        </Button>
                                    </Form>
                                }
                            />
                        </Col>
                    </Row>
                </Grid>
            </div>
        );
    }
}

export default Create;
