// 7. turn on bulbs
package main

import "fmt"

func Check(turn_on []int) bool {
	for i := 1; i < len(turn_on); i++ {
		if turn_on[i-1] == 0 && turn_on[i] == 1 {
			return false
		}
	}
	return true
}

func Solution(a []int) int {
	count := 0
	turn_on := []int{}
	for _, v := range a {
		turn_on = append(turn_on, 0)
		v = v * 1
	}
	for i := 0; i < len(a); i++ {
		turn_on[a[i]-1] = 1
		if Check(turn_on) {
			count++
		}
	}
	return count
}

func main() {
	a := []int{1, 3, 4, 2, 5}
	fmt.Println(Solution(a))
}
