// Count the most of words in a sentences
package main

import (
	"fmt"
)

func Solution(s string) int {
	count := 0
	count_arr := []int{}
	for i := 0; i < len(s)-1; i++ {
		if s[i] != ' ' && s[i+1] == ' ' && s[i] != '.' || s[i] != ' ' && s[i+1] == '.' {
			count++
		} else if s[i] == '.' || i+1 == len(s)-1 {
			count_arr = append(count_arr, count)
			count = 0
		}
		if i+1 == len(s)-1 {
			count_arr = append(count_arr, count)
		}
	}
	// Max
	var max int
	for i, v := range count_arr {
		if i == 0 || v > max {
			max = v
		}
	}
	return max
}

func main() {
	s := "John ate the.  caadny.   x.x."
	fmt.Println(Solution(s))
}

//6
