package main

import (
	"fmt"
	"log"
)

func CheckOrder(n_temp []int) bool {
	for i := 1; i < len(n_temp)-1; i++ {
		if n_temp[i] > n_temp[i+1] {
			return false
		}
	}
	return true
}
func Cut(ns []int) int {
	flag := 0
	count := 0
	temp := []int{}
	for i := 0; i < len(ns); i++ {
		for j := 0; j < len(ns); j++ {
			if j == i {
				continue
			}
			temp = append(temp, ns[j])
			log.Println(temp, i)
		}
		if CheckOrder(temp) {
			count++
		} else {
			flag++
			if flag > 1 {
				return 0
			}
		}
		temp = []int{}
	}
	return count
}

func main() {
	ns := []int{1, 2, 3, 3, 5}
	fmt.Println(Cut(ns))
}
