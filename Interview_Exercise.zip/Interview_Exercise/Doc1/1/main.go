//1 . edit phone number
package main

import (
	"fmt"
	"log"
)

func EditPhoneNumber(s string) string {
	temp := make([]string, 0)
	result := ""
	for i := 0; i < len(s); i++ {
		if s[i] == '-' || s[i] == ' ' {
			continue
		}
		temp = append(temp, string(s[i]))

	}
	log.Println(temp)
	flag := 0
	for i := 0; i < len(temp); i++ {
		if flag == 3 {
			result = result + "-"
			flag = 0
		}
		if (len(temp))%2 == 0 && i == len(temp)-2 {
			result = result + "-"
			flag = 0
		}
		result = result + string(temp[i])
		flag++
	}
	log.Println(result)

	// if (len(temp)-1)%2 == 0 {
	// 	result[len(temp)-3], result[len(temp)-2] = result[len(temp)-2], result[len(temp)-3]
	// }
	return ""
}

func main() {
	s1 := "02213456424"
	//s := "0221985324"
	fmt.Println(EditPhoneNumber(s1))
}
