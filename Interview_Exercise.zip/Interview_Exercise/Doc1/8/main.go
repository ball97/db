// 8.Vaction
package main

import "fmt"

func dayofweek(y, m, d int) int {
	t := []int{0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4}
	if m < 3 {
		y--
	}
	return (y + y/4 - y/100 + y/400 + t[m-1] + d) % 7
}
func Solution(y int, a, b, w string) int {
	month := map[string]int{
		"January":   1,
		"February":  2,
		"March":     3,
		"April":     4,
		"May":       5,
		"Jun":       6,
		"July":      7,
		"August":    8,
		"September": 9,
		"October":   10,
		"November":  11,
		"December":  12,
	}
	dateofmonth := map[string]int{
		"January":   31,
		"February":  28,
		"March":     31,
		"April":     30,
		"May":       31,
		"Jun":       30,
		"July":      31,
		"August":    31,
		"September": 30,
		"October":   31,
		"November":  30,
		"December":  31,
	}
	// day := map[string]int{
	// 	"Monday":    1,
	// 	"Thurday":   2,
	// 	"Tuesday":   3,
	// 	"Wednesday": 4,
	// 	"Thursday":  5,
	// 	"Friday":    6,
	// 	"Staturday": 7,
	// 	"Sunday":    0,
	// }
	total := dateofmonth[a] + dateofmonth[b]
	start := dayofweek(y, month[a], 1)
	if start != 1 {
		switch start {
		case 0:
			{
				total = total - 1
				break
			}
		case 2:
			{
				total = total - 6
				break
			}
		case 3:
			{
				total = total - 5
				break
			}
		case 4:
			{
				total = total - 4
				break
			}
		case 5:
			{
				total = total - 3
				break
			}
		case 6:
			{
				total = total - 2
				break
			}
		}
		var end int
		if month[b] == 2 && y%4 == 0 {
			end = dayofweek(y, month[b], dateofmonth[b]+1)
		} else {
			end = dayofweek(y, month[b], dateofmonth[b])
		}
		if end != 0 {
			switch start {
			case 1:
				{
					total = total - 1
					break
				}
			case 2:
				{
					total = total - 2
					break
				}
			case 3:
				{
					total = total - 3
					break
				}
			case 4:
				{
					total = total - 4
					break
				}
			case 5:
				{
					total = total - 5
					break
				}
			case 6:
				{
					total = total - 6
					break
				}
			}

		}
	}
	if month[b] == 2 && y%4 == 0 {
		return total + 1
	}
	return total
}
func main() {

	y := 2014
	a := "April"
	b := "May"
	w := "Wednesday"
	fmt.Println(Solution(y, a, b, w) / 7)
}
