//6.
package main

import (
	"fmt"
	"log"
	"strings"
)

func CheckAdd(s string, t string) string {
	temp := s
	if len(s) > len(t) {
		temp = strings.Replace(s, t, "", -1)
		return temp
	}
	temp = strings.Replace(t, s, "", -1)
	return temp
}
func CheckChange(s, t string) []string {
	if len(s) != len(t) {
		return nil
	}
	result := []string{}
	flag := 0
	for i := 0; i < len(s); i++ {
		if s[i] != t[i] {
			flag++
			result = append(result, string(s[i]))
			result = append(result, string(t[i]))
		}
		if flag > 1 {
			return nil
		}
	}
	return result
}
func CheckMove(s, t string) string {
	if len(s) != len(t) {
		return ""
	}
	result := ""
	for i, j := 0, 0; i < len(s); i, j = i+1, j+1 {
		// Mark the charater that moved
		if s[i] != t[j] && result == "" {
			result = string(s[i])
			log.Println(result)
			continue
		}
		// Check each character when the mark is located i, i-1
		if result != "" && s[i] != t[j-1] && s[i] != t[j] {
			log.Println("1", s[i], s[j-1], i, j)
			return ""
		}
		// Where the moved character is at beans - banes
		if result != "" && s[i] == t[j] && string(t[j-1]) != result {
			log.Println("2", s[i], s[j])
			return ""
		}
		// Where the moved character is at beans - eansb
		if i == len(s)-1 && s[i] != t[j] && result != "" && result != string(t[j]) {
			log.Println("3", s[i], s[j], i, j)
			return ""
		}

	}
	return result
}

func Solution(s, t string) {
	if s == t {
		fmt.Println("Nothing")
		return
	}
	add := CheckAdd(s, t)
	if len(add) == 1 {
		fmt.Println("ADD ", add)
		return
	}

	change := CheckChange(s, t)
	if change != nil {
		fmt.Println("Change ", change)
		return
	}
	move := CheckMove(s, t)
	if move != "" {
		fmt.Println("Move ", move)
		return
	}

	fmt.Print("IMPOSSIBLE")

}
func main() {
	s := "beans"
	t := "beasnd"
	Solution(s, t)
}
