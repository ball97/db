// 10. For a single swap. Check if the given array can be the non-decresing order
package main

import (
	"fmt"
	"log"
)

func FirstCheck(n_temp []int) bool {
	var prev int
	for i, v := range n_temp {
		if i == 0 {
			prev = v
		}
		if v < prev {
			return false
		}
		prev = v
	}
	return true
}
func CheckOrder(n_temp []int) bool {
	var prev int
	for i, v := range n_temp {
		if i == 0 {
			prev = v
		}
		if v < prev {
			return false
		}
		prev = v
	}
	return true
}
func Solution(ns []int) bool {
	temp := make([]int, len(ns))
	copy(temp, ns)
	for i := 0; i < len(temp)-1; i++ {
		for j := i; j < len(temp); j++ {
			temp[i], temp[j] = temp[j], temp[i]
			log.Println(temp)
			if CheckOrder(temp) {
				return true
			} else {
				copy(temp, ns)
			}
		}
		log.Println(temp)

	}
	return false
}

func main() {
	ns := []int{1, 2, 3, 7, 6}
	log.Println(ns)
	if FirstCheck(ns) {
		fmt.Println("True")
	} else {
		log.Println("secaond")
		fmt.Println(Solution(ns))
	}
}
