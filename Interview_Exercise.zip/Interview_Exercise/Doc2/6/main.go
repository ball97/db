//6. You are given two non-empty linked lists representing two non-negative integers. T
//he digits are stored in reverse order and each of their nodes contain a single digit.
//Add the two numbers and return it as a linked list.
package main

import (
	"fmt"
)

type number struct {
	num  int
	next *number
}

// Head is Starting point
var head *number

// Read All Node
func PrintList(head *number) {
	for n := head; n != nil; n = n.next {
		fmt.Println(n)
	}
}

// Add Node
func AddNodeEnd(newnumber, head *number) *number {
	if head == nil {
		head = newnumber
		return head
	}
	for n := head; n != nil; n = n.next {
		if n.next == nil {
			n.next = newnumber
			return head
		}
	}
	return head
}

// ReverseList
func ReverseList(prev, next, head *number) *number {
	n := head
	for n != nil {
		next = n.next
		n.next = prev
		prev = n
		n = next
	}
	head = prev
	return head
}

// Convert to int
func NodeToInt(head *number) int {
	i := 0
	for n := head; n != nil; n = n.next {
		i = i*10 + n.num
	}
	return i
}
func main() {
	v11 := &number{2, nil}
	v12 := &number{5, nil}
	v13 := &number{5, nil}

	v11 = AddNodeEnd(v12, v11)
	v11 = AddNodeEnd(v13, v11)
	PrintList(v11)
	v21 := &number{6, nil}
	v22 := &number{3, nil}
	v23 := &number{4, nil}
	v21 = AddNodeEnd(v22, v21)
	v21 = AddNodeEnd(v23, v21)
	//PrintList(v21)
	v11 = ReverseList(nil, nil, v11)
	v21 = ReverseList(nil, nil, v21)
	PrintList(v11)
	PrintList(v21)
	fmt.Println(NodeToInt(v11) + NodeToInt(v21))

}
