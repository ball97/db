//5. Write a function to find the longest common prefix string amongst an array of strings.
//If there is no common prefix, return an empty string "".
package main

import (
	"fmt"
)

func FindLongestCommonPrefilxString(s []string) string {
	// Take the first element and compare it to each element in array s,
	// Only take characters that are the same among the array
	temp := s[0]
	prefix := ""
	flag := true // This flag determine when the loop for prefix has no break point
	for i := 1; i < len(s); i++ {
		for k := 0; k < len(temp); k++ {
			if temp[k] == s[i][k] {
				prefix = prefix + string(temp[k])
			} else { // If there is a different while comparing the prefix with s[i] break and move on
				temp = prefix
				prefix = ""
				flag = false
				break
			}
		}
		if flag == true {
			temp = prefix
			prefix = ""
		} else {
			flag = true
		}

	}
	return temp

}

func main() {
	s := []string{"a", "flight", "floor", "a"}
	result := FindLongestCommonPrefilxString(s)
	fmt.Printf("Original String: %s\nThe Longest Common Prefix String: %s", s, result)
}
