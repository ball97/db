//7. Longest Substring without Repeating Characters
package main

import (
	"fmt"
	"log"
)

func FindSub(s string) int {
	if s == "" {
		return 0
	}
	frequency_table := make(map[byte]int)

	temp_count := 1
	count := 0
	for i := 0; i < len(s)-1; i++ {
		frequency_table[s[i]]++
		for j := i + 1; j < len(s); j++ {
			frequency_table[s[j]]++
			log.Println((frequency_table[s[j]]))
			if frequency_table[s[j]] > 1 {
				if temp_count > count {
					count = temp_count
				}
				log.Println("temp_count: ", temp_count)
				frequency_table = make(map[byte]int)
				break
			}
			temp_count++
		}
		if temp_count > count {
			count = temp_count
		}
		temp_count = 1
		frequency_table = make(map[byte]int)
	}
	return count
}

func main() {
	s := "abcacbee"
	fmt.Println(FindSub(s))
}
