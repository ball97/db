//8. Longest Palindromic Substring
package main

import (
	"fmt"
	"log"
	"strings"
)

func Reverse(s []string) []string {
	result := s
	for i, j := 0, len(s)-1; j > i; i, j = i+1, j-1 {
		result[i], result[j] = result[j], result[i]
	}
	return result
}
func CheckPalindromic(s_arr []string) bool {
	s_original := strings.Join(s_arr, "")
	s_reverse := strings.Join(Reverse(s_arr), "")
	if s_original == s_reverse {
		return true
	}
	return false
}

func LongestPalindromicSubstring(s_arr []string) int {
	temp_longest := 0
	result := 0
	for i := 2; i < len(s_arr)-i; i++ {
		for j := 0; j < len(s_arr)-2; j++ {
			temp := s_arr[j : i+j]
			log.Println(temp, i, j)
			if CheckPalindromic(temp) {
				temp_longest = j - i
				if temp_longest > result {
					result = temp_longest
				}
			}
		}
	}
	return result
}

func main() {
	s := "ABCDEF"
	s_arr := strings.Split(s, "")
	// if CheckPalindromic(s_arr) {
	// 	fmt.Println("true")
	// } else {
	// 	fmt.Println("false")
	// }
	fmt.Println(LongestPalindromicSubstring(s_arr))
}
