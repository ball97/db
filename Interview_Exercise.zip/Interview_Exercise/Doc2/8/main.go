//8. Longest Palindromic Substring
package main

import (
	"fmt"
)

func CheckPalindromic(s string) bool {
	j := len(s) - 1
	for i := 0; i < len(s)/2; i++ {
		if s[i] != s[j] {
			return false
		}
		j--
	}
	return true
}

func LongestPalindromicSubstring(s string) string {
	result := ""
	for i := 1; i <= len(s); i++ {
		for j := 0; j < len(s)-i+1; j++ {
			temp := s[j : j+i]
			//fmt.Println(temp)
			if CheckPalindromic(temp) {
				result = temp
				break
			}
		}
	}
	return result
}

func main() {
	s := "ABBAAS"
	// if CheckPalindromic(s) {
	// 	fmt.Println("true")
	// } else {
	// 	fmt.Println("false")
	// }
	fmt.Println(LongestPalindromicSubstring(s))
}
