package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/dgrijalva/jwt-go"

	"github.com/gorilla/mux"

	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

var Abc *mgo.Session

type Category struct {
	Id          bson.ObjectId `bson:"_id,omitempty"`
	Name        string
	Description string
	Movies      []Movie
}
type Movie struct {
	Name         string
	ReleasedDate time.Time
}
type DataStore struct {
	session *mgo.Session
}
type Login struct {
	pass string
	role string
}

//Close session
func (d *DataStore) Close() {
	d.session.Close()
}

// Map to database
func (d *DataStore) C(db string, collection string) *mgo.Collection {
	return d.session.DB(db).C(collection)
}
func NewDataStore() *DataStore {
	ds := &DataStore{
		session: Abc.Copy(),
	}
	return ds
}

func PostCategory(w http.ResponseWriter, r *http.Request) {
	ca := Category{}
	err := json.NewDecoder(r.Body).Decode(&ca)
	if err != nil {
		panic(err)
		//w.Write(err)
	}
	ca.Id = bson.NewObjectId()
	ds := NewDataStore()
	err = ds.C("test", "categories").Insert(&ca)
	if err != nil {
		panic(err)
	}
	defer ds.Close()
	j, err := json.Marshal(ca)
	if err != nil {
		log.Println("Post-Marshall")
		panic(err)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}
func GetAllCategory(w http.ResponseWriter, r *http.Request) {
	var ca []Category
	var t Category
	//var ds *mgo.Session
	temp := Abc.DB("test").C("categories").Find(nil).Iter()
	//	temp := ds.C("test", "categories").Find(nil).Iter()
	for temp.Next(&t) {
		ca = append(ca, t)
	}
	defer temp.Close()

	err := json.NewEncoder(w).Encode(&ca)
	if err != nil {
		log.Println("GetAll-Encode")
		panic(err)
		//w.Write(err)
	}
}
func PutCategory(w http.ResponseWriter, r *http.Request) {
	var newca Category
	err := json.NewDecoder(r.Body).Decode(&newca)
	if err != nil {
		log.Println("Decode-Put")
		panic(err)
	}
	ds := NewDataStore()
	err = ds.C("test", "categories").Update(
		bson.M{"_id": newca.Id},
		bson.M{"$set": bson.M{
			"name":        newca.Name,
			"description": newca.Description,
			"Movies":      newca.Movies,
		}})
	if err != nil {
		log.Println("Update-Put")
		panic(err)
	}
}
func DeleteCategory(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	temp := vars["id"]
	id := bson.ObjectIdHex(temp)
	log.Println(id)
	ds := NewDataStore()
	ds.C("test", "categories").RemoveId(id)
}
func GetJWT(w http.ResponseWriter, r *http.Request) {
	var login Login
	err := json.NewDecoder(r.Body).Decode(&login)
	if err != nil {
		panic(err)
	}

	hashpass := sha256.New()
	hashpass.Write([]byte(login.pass))
	t, _ := fmt.Printf("%x", hashpass.Sum(nil))
	ds := NewDataStore()
	temp := ds.C("test", "passwords").Find(bson.M{"pass": t}).One(&login)
	log.Println(t)
	if temp != nil {

		key := []byte("string")
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
			"role": login.role,
			"exp":  10 * time.Second,
		})
		tokenString, err := token.SignedString(key)
		if err != nil {
			panic(err)
		}
		j, err := json.Marshal(tokenString)
		if err != nil {
			panic(err)
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		w.Write(j)
	} else {
		fmt.Fprintf(w, "Not Found")
	}

}

func CheckJWT(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tokenString := vars["jwt"]
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		return []byte("string"), nil
	})
	if err == nil && token.Valid {
		fmt.Fprintf(w, "token is valid")
	}
}
func main() {
	var err error
	Abc, err = mgo.Dial("localhost:27017")
	if err != nil {
		log.Println("Create Session")
		panic(err)
	}
	Abc.SetMode(mgo.Monotonic, true)
	r := mux.NewRouter()
	r.HandleFunc("/post", PostCategory).Methods("POST")
	r.HandleFunc("/getall", GetAllCategory).Methods("GET")
	r.HandleFunc("/update", PutCategory).Methods("PUT")
	r.HandleFunc("/delete/{id}", DeleteCategory).Methods("DELETE")
	r.HandleFunc("/jwt", GetJWT).Methods("GET")
	r.HandleFunc("/checkjwt/{jwt}", CheckJWT).Methods("GET")

	server := &http.Server{
		Addr:    ":8080",
		Handler: r,
	}
	log.Print("Start listenning on port 8080")
	server.ListenAndServe()

	//Insert
	// doc1 := &Category{
	// 	bson.NewObjectId(),
	// 	"Action",
	// 	"Violent",
	// }
	// err = c.Insert(doc1)
	// if err != nil {
	// 	panic(err)
	// }
	//c.RemoveAll(nil)
	// err = c.Insert(&Category{bson.NewObjectId(), "Romantic", "Hot", []Movie{}},
	// 	&Category{bson.NewObjectId(), "Fantasty", "High", []Movie{}},
	// 	&Category{bson.NewObjectId(), "Violent", "Action", []Movie{}},
	// 	&Category{bson.NewObjectId(), "Comedy", "12+", []Movie{}})
	// if err != nil {
	// 	panic(err)
	// }
	// index := mgo.Index{
	// 	Key:        []string{"name", "description"},
	// 	Unique:     true,
	// 	DropDups:   true,
	// 	Background: true,
	// }
	// err = c.EnsureIndex(index)
	// if err != nil {
	// 	panic(err)
	// }
	// log := ""
	// //result := Category{}
	// err = c.Find(bson.M{"description": "Action"}).Explain(log)
	// if err != nil {
	// 	panic(err)
	// }
	//fmt.Println(result.Name)

	//c.RemoveAll(nil)
	//Insert form Map and Slice
	// doc1 := map[string]string{
	// 	"name":        "Cartoon",
	// 	"description": "12+",
	// }
	// err = c.Insert(doc1)
	// if err != nil {
	// 	panic(err)
	// }
	// docD := bson.D{
	// 	{"name", "Project"},
	// 	{"description", "Project Tasks"},
	// }
	// //insert a document slice
	// err = c.Insert(docD)
	// if err != nil {
	// 	log.Fatal(err)
	// }
	////Insert Embebed Document
	// Doc2 := &Category{
	// 	bson.NewObjectId(),
	// 	"Comedy",
	// 	"Laugh",
	// 	[]Movie{Movie{"a", time.Date(2019, 25, 1, 12, 12, 12, 0, time.UTC)}, Movie{"b", time.Date(2019, 26, 1, 12, 12, 12, 0, time.UTC)}},
	// }
	// err = c.Insert(Doc2)
	// if err != nil {
	// 	panic(err)
	// }
	//Count
	// count, err := c.Count()
	// if err != nil {
	// 	panic(err)
	// }
	// fmt.Println(count)
	//Find All
	// iter := c.Find(nil).Iter()
	// temp := Category{}
	// result := make([]Category, 0)
	// for iter.Next(&temp) {
	// 	result = append(result, temp)
	// }
	// for _, v := range result {
	// 	fmt.Println(v)
	// }
	////Sorting
	// iter := c.Find(nil).Sort("name").Iter()
	// temp := Category{}
	// result := make([]Category, 0)
	// for iter.Next(&temp) {
	// 	result = append(result, temp)
	// }
	// for _, v := range result {
	// 	fmt.Println(v)
	// }
	// Retrieving a single record
	// result := Category{}
	// err = c.Find(bson.M{"name": "Action"}).One(&result)
	// if err != nil {
	// 	panic(err)
	// }
	// fmt.Println(result)
	//// Update
	// err = c.Update(bson.M{"name": "Action"},
	// 	bson.M{"$set": bson.M{
	// 		"description": "Not Action",
	// 	}})
	// if err != nil {
	// 	panic(err)
	// }
	////Delete
	// err = c.Remove(bson.M{"name": "Action"})
	// if err != nil {
	// 	panic(err)
	// }
	// _, err = c.RemoveAll(nil)
	// if err != nil {
	// 	panic(err)
	// }
}
