package main

import (
	"fmt"
	"time"

	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type Category struct {
	Id          bson.ObjectId `bson:"_id,omitempty"`
	Name        string
	Description string
	Movies      []Movie
}
type Movie struct {
	Name         string
	ReleasedDate time.Time
}

func main() {
	session, err := mgo.Dial("localhost")
	if err != nil {
		panic(err)
	}
	defer session.Close()
	session.SetMode(mgo.Monotonic, true)

	c := session.DB("test").C("categories")
	//Insert
	// doc1 := &Category{
	// 	bson.NewObjectId(),
	// 	"Action",
	// 	"Violent",
	// }
	// err = c.Insert(doc1)
	// if err != nil {
	// 	panic(err)
	// }
	// err = c.Insert(&Category{bson.NewObjectId(), "Romantic", "Hot"},
	// 			&Category{bson.NewObjectId(), "Fantasty", "High"})
	// if err != nil {
	// 	panic(err)
	// }
	//Insert form Map and Slice
	// doc1 := map[string]string{
	// 	"name":        "Cartoon",
	// 	"description": "12+",
	// }
	// err = c.Insert(doc1)
	// if err != nil {
	// 	panic(err)
	// }
	// docD := bson.D{
	// 	{"name", "Project"},
	// 	{"description", "Project Tasks"},
	// }
	// //insert a document slice
	// err = c.Insert(docD)
	// if err != nil {
	// 	log.Fatal(err)
	// }
	////Insert Embebed Document
	// Doc2 := &Category{
	// 	bson.NewObjectId(),
	// 	"Comedy",
	// 	"Laugh",
	// 	[]Movie{Movie{"a", time.Date(2019, 25, 1, 12, 12, 12, 0, time.UTC)}, Movie{"b", time.Date(2019, 26, 1, 12, 12, 12, 0, time.UTC)}},
	// }
	// err = c.Insert(Doc2)
	// if err != nil {
	// 	panic(err)
	// }
	//Count
	// count, err := c.Count()
	// if err != nil {
	// 	panic(err)
	// }
	// fmt.Println(count)
	////Find All
	// iter := c.Find(nil).Iter()
	// temp := Category{}
	// result := make([]Category, 0)
	// for iter.Next(&temp) {
	// 	result = append(result, temp)
	// }
	// for _, v := range result {
	// 	fmt.Println(v)
	// }
	////Sorting
	iter := c.Find(nil).Sort("name").Iter()
	temp := Category{}
	result := make([]Category, 0)
	for iter.Next(&temp) {
		result = append(result, temp)
	}
	for _, v := range result {
		fmt.Println(v)
	}
}
